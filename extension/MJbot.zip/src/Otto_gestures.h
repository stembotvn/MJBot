#ifndef Otto_gestures_h
#define Otto_gestures_h

#define OttoHappy     0
#define OttoSuperHappy  1
#define OttoSad     2
#define OttoSleeping  3
#define OttoFart    4
#define OttoConfused  5
#define OttoLove    6
#define OttoAngry     7
#define OttoFretful   8
#define OttoMagic     9
#define OttoWave    10
#define OttoVictory   11
#define OttoFail    12

//*** MOUTH ANIMATIONS***
#define littleUuh   0
#define dreamMouth    1   
#define adivinawi   2
#define wave      3


#endif
